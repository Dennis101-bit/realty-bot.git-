"""
Harbor Realty WhatsApp Bot
--------------------------
Flask + Twilio webhook backend.
Every WhatsApp message Twilio receives is POSTed to /webhook.
The bot replies using TwiML (Twilio Markup Language).

Deploy to Railway.app or Render.com, then paste your public URL
into your Twilio WhatsApp sandbox webhook field.
"""

from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
from sheets import get_properties, find_properties, get_property_by_id
from leads import save_lead, notify_agent
from session import get_session, set_session, clear_session

app = Flask(__name__)

# ─── Greeting ────────────────────────────────────────────────────────────────

MENU = (
    "Hi! Welcome to Harbor Realty 👋\n"
    "Are you looking to:\n\n"
    "1️⃣  Find Properties\n"
    "2️⃣  Get Property Information\n"
    "3️⃣  Book an Appointment\n\n"
    "Reply with 1, 2, or 3 to choose an option."
)

# ─── Webhook ──────────────────────────────────────────────────────────────────

@app.route("/webhook", methods=["POST"])
def webhook():
    sender  = request.form.get("From", "")   # e.g. whatsapp:+18761234567
    body    = request.form.get("Body", "").strip()
    msg_lower = body.lower()

    session = get_session(sender)
    step    = session.get("step", "menu")
    data    = session.get("data", {})

    resp = MessagingResponse()
    msg  = resp.message()

    # ── Always allow "menu" or "hi" to reset ─────────────────────────────────
    if msg_lower in ("menu", "hi", "hello", "start", "reset"):
        clear_session(sender)
        msg.body(MENU)
        return str(resp)

    # ── Main menu ─────────────────────────────────────────────────────────────
    if step == "menu":
        if body in ("1", "find properties", "find"):
            set_session(sender, {"step": "find_criteria", "data": {}})
            msg.body(
                "Great! What are you looking for?\n\n"
                "You can tell me:\n"
                "• Area (e.g. Riverside, Downtown)\n"
                "• Bedrooms (e.g. 3 bedroom)\n"
                "• Or both (e.g. 2 bedroom downtown)\n\n"
                "What's your preference?"
            )
        elif body in ("2", "get property info", "info"):
            set_session(sender, {"step": "info_id", "data": {}})
            msg.body(
                "Sure! Reply with the Property ID (e.g. P-101).\n\n"
                "Don't know the ID? Reply LIST to see all available properties."
            )
        elif body in ("3", "book", "book an appointment", "appointment"):
            set_session(sender, {"step": "book_name", "data": {}})
            msg.body("Let's book you in! 📅\n\nFirst, what's your full name?")
        else:
            msg.body(
                "Sorry, I didn't catch that. 😊\n\n" + MENU
            )

    # ── Find properties ───────────────────────────────────────────────────────
    elif step == "find_criteria":
        results = find_properties(body)
        if results:
            lines = ["Here's what I found:\n"]
            for p in results:
                lines.append(
                    f"🏠 *{p['id']}* — {p['title']}\n"
                    f"   {p['price']} · {p['beds']} bed · {p['baths']} bath · {p['sqft']} sqft\n"
                )
            lines.append("Reply with a Property ID for full details, or type MENU to start over.")
            set_session(sender, {"step": "info_id", "data": {}})
            msg.body("\n".join(lines))
        else:
            msg.body(
                "I couldn't find an exact match, but here are our latest listings:\n\n"
                + _all_listings_text()
                + "\nReply with a Property ID for full details."
            )
            set_session(sender, {"step": "info_id", "data": {}})

    # ── Property info ─────────────────────────────────────────────────────────
    elif step == "info_id":
        if msg_lower == "list":
            msg.body("Here are all available properties:\n\n" + _all_listings_text())
        else:
            p = get_property_by_id(body)
            if p:
                msg.body(
                    f"🏠 *{p['title']}*\n\n"
                    f"💰 Price: {p['price']}\n"
                    f"🛏  Beds: {p['beds']}\n"
                    f"🚿 Baths: {p['baths']}\n"
                    f"📐 Size: {p['sqft']} sqft\n"
                    f"📍 Area: {p['area']}\n\n"
                    f"{p['desc']}\n\n"
                    "Interested? Reply BOOK to arrange a viewing, or MENU to start over."
                )
                set_session(sender, {"step": "info_id", "data": {"last_property": p["id"]}})
            elif msg_lower in ("book", "book an appointment"):
                set_session(sender, {"step": "book_name", "data": {}})
                msg.body("Let's book you in! 📅\n\nFirst, what's your full name?")
            else:
                msg.body(
                    "I couldn't find that Property ID. 🤔\n\n"
                    "Reply LIST to see all properties, or MENU to start over."
                )

    # ── Booking flow ──────────────────────────────────────────────────────────
    elif step == "book_name":
        data["name"] = body
        set_session(sender, {"step": "book_phone", "data": data})
        msg.body(f"Nice to meet you, {body}! 😊\n\nWhat's the best phone number to reach you?")

    elif step == "book_phone":
        data["phone"] = body
        set_session(sender, {"step": "book_property", "data": data})
        msg.body("Which property would you like to view?\n(Reply with the Property ID, e.g. P-101, or describe it)")

    elif step == "book_property":
        data["property"] = body
        set_session(sender, {"step": "book_time", "data": data})
        msg.body("What day and time works best for you? 📅\n(e.g. Saturday 10am, or weekday afternoons)")

    elif step == "book_time":
        data["time"] = body
        # Save lead to Google Sheet + email agent
        save_lead(data)
        notify_agent(data)
        clear_session(sender)
        msg.body(
            f"✅ *Booking request received!*\n\n"
            f"📋 Name: {data['name']}\n"
            f"📞 Phone: {data['phone']}\n"
            f"🏠 Property: {data['property']}\n"
            f"🕐 Preferred time: {data['time']}\n\n"
            "An agent will confirm with you shortly. Thank you! 🙏\n\n"
            "Type MENU if you need anything else."
        )

    # ── Fallback ──────────────────────────────────────────────────────────────
    else:
        clear_session(sender)
        msg.body("Let's start fresh! 😊\n\n" + MENU)

    return str(resp)


# ─── Helper ───────────────────────────────────────────────────────────────────

def _all_listings_text():
    props = get_properties()
    lines = []
    for p in props:
        lines.append(f"• *{p['id']}* — {p['title']} | {p['price']}")
    return "\n".join(lines) + "\n"


# ─── Run ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app.run(debug=True, port=5000)
