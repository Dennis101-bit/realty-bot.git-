"""
leads.py
--------
When someone completes a booking request, this module:
1. Saves the lead to a Google Sheet (the agent's lead log)
2. Sends the agent an email notification via SendGrid

SETUP:
- Set LEADS_SPREADSHEET_ID in .env (a separate sheet from your listings)
- Set SENDGRID_API_KEY, AGENT_EMAIL, and FROM_EMAIL in .env
- The leads sheet needs these columns: Name | Phone | Property | Time | Received
"""

import os
import gspread
from datetime import datetime
from google.oauth2.service_account import Credentials

# ─── Save lead to Google Sheet ────────────────────────────────────────────────

def save_lead(data: dict):
    """Append the booking request to the leads Google Sheet."""
    spreadsheet_id = os.getenv("LEADS_SPREADSHEET_ID")
    if not spreadsheet_id:
        print(f"[leads] No LEADS_SPREADSHEET_ID set. Lead data: {data}")
        return

    try:
        scopes = [
            "https://www.googleapis.com/auth/spreadsheets",
            "https://www.googleapis.com/auth/drive"
        ]
        creds  = Credentials.from_service_account_file("credentials.json", scopes=scopes)
        client = gspread.authorize(creds)
        sheet  = client.open_by_key(spreadsheet_id).sheet1
        sheet.append_row([
            data.get("name", ""),
            data.get("phone", ""),
            data.get("property", ""),
            data.get("time", ""),
            datetime.now().strftime("%Y-%m-%d %H:%M")
        ])
        print(f"[leads] Lead saved: {data['name']}")
    except Exception as e:
        print(f"[leads] Could not save lead to sheet: {e}")


# ─── Email agent via SendGrid ─────────────────────────────────────────────────

def notify_agent(data: dict):
    """Send the agent an email with the new lead details."""
    api_key     = os.getenv("SENDGRID_API_KEY")
    agent_email = os.getenv("AGENT_EMAIL")
    from_email  = os.getenv("FROM_EMAIL", "bot@harberrealty.com")

    if not api_key or not agent_email:
        print(f"[leads] SendGrid not configured. Would have emailed: {data}")
        return

    try:
        import sendgrid
        from sendgrid.helpers.mail import Mail

        subject = f"New Booking Request — {data.get('name', 'Unknown')}"
        content = (
            f"You have a new booking request from your WhatsApp assistant:\n\n"
            f"Name:             {data.get('name', '')}\n"
            f"Phone:            {data.get('phone', '')}\n"
            f"Property:         {data.get('property', '')}\n"
            f"Preferred time:   {data.get('time', '')}\n"
            f"Received:         {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n"
            "Please follow up as soon as possible.\n\n"
            "— Harbor Realty Assistant"
        )

        sg      = sendgrid.SendGridAPIClient(api_key=api_key)
        message = Mail(
            from_email=from_email,
            to_emails=agent_email,
            subject=subject,
            plain_text_content=content
        )
        sg.send(message)
        print(f"[leads] Agent notified at {agent_email}")
    except Exception as e:
        print(f"[leads] Could not send email: {e}")
