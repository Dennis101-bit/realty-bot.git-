"""
session.py
----------
Tracks where each user is in the conversation (their "step") and any
data collected so far (name, phone, etc).

Uses a simple in-memory dict for now — good enough for a prototype.
For production, swap the dict for Redis or a database so sessions
survive a server restart.
"""

_sessions = {}

def get_session(sender: str) -> dict:
    """Return the current session for this WhatsApp number."""
    return _sessions.get(sender, {"step": "menu", "data": {}})

def set_session(sender: str, session: dict):
    """Save/update the session for this WhatsApp number."""
    _sessions[sender] = session

def clear_session(sender: str):
    """Reset the session (user back to main menu)."""
    _sessions[sender] = {"step": "menu", "data": {}}
