"""
sheets.py
---------
Reads property listings from a Google Sheet.

SETUP (one time):
1. Create a Google Sheet with these columns in row 1:
   ID | Title | Price | Beds | Baths | Sqft | Area | Description | Status

2. Share the sheet with your Google service account email (from credentials.json)

3. Set SPREADSHEET_ID in your .env file

The MOCK_PROPERTIES list below is used as a fallback when Google Sheets
is not configured — so the bot works out of the box for testing.
"""

import os
import gspread
from google.oauth2.service_account import Credentials

# ─── Mock data (used when Google Sheets is not configured) ────────────────────

MOCK_PROPERTIES = [
    {
        "id": "P-101",
        "title": "2BR Condo, Riverside Ave",
        "price": "$320,000",
        "beds": "2",
        "baths": "2",
        "sqft": "1100",
        "area": "Riverside",
        "desc": "Bright corner unit with balcony, walking distance to transit. Building has gym and pool.",
        "status": "Active"
    },
    {
        "id": "P-102",
        "title": "3BR House, Maple Street",
        "price": "$540,000",
        "beds": "3",
        "baths": "2",
        "sqft": "1850",
        "area": "Maple Heights",
        "desc": "Detached home with fenced backyard, renovated kitchen, attached garage.",
        "status": "Active"
    },
    {
        "id": "P-103",
        "title": "Studio Apartment, Downtown Loft",
        "price": "$210,000",
        "beds": "0",
        "baths": "1",
        "sqft": "540",
        "area": "Downtown",
        "desc": "Modern loft-style studio, exposed brick, rooftop access, steps from cafes.",
        "status": "Active"
    },
    {
        "id": "P-104",
        "title": "4BR House, Lakeview Drive",
        "price": "$725,000",
        "beds": "4",
        "baths": "3",
        "sqft": "2600",
        "area": "Lakeview",
        "desc": "Lakefront property with private dock, open-plan living, finished basement.",
        "status": "Active"
    },
]

# ─── Google Sheets connection ──────────────────────────────────────────────────

def _get_sheet():
    """Connect to Google Sheets and return the worksheet."""
    spreadsheet_id = os.getenv("SPREADSHEET_ID")
    if not spreadsheet_id:
        return None
    try:
        scopes = ["https://www.googleapis.com/auth/spreadsheets.readonly"]
        creds  = Credentials.from_service_account_file("credentials.json", scopes=scopes)
        client = gspread.authorize(creds)
        return client.open_by_key(spreadsheet_id).sheet1
    except Exception as e:
        print(f"[sheets] Could not connect to Google Sheets: {e}")
        return None

def _sheet_to_dicts(sheet):
    """Convert sheet rows to list of property dicts."""
    rows = sheet.get_all_records()
    return [
        {
            "id":    str(r.get("ID", "")).strip(),
            "title": str(r.get("Title", "")).strip(),
            "price": str(r.get("Price", "")).strip(),
            "beds":  str(r.get("Beds", "")).strip(),
            "baths": str(r.get("Baths", "")).strip(),
            "sqft":  str(r.get("Sqft", "")).strip(),
            "area":  str(r.get("Area", "")).strip(),
            "desc":  str(r.get("Description", "")).strip(),
            "status":str(r.get("Status", "Active")).strip(),
        }
        for r in rows
        if str(r.get("Status", "")).strip().lower() == "active"
    ]

# ─── Public API ───────────────────────────────────────────────────────────────

def get_properties() -> list:
    """Return all active properties."""
    sheet = _get_sheet()
    if sheet:
        return _sheet_to_dicts(sheet)
    return MOCK_PROPERTIES

def get_property_by_id(property_id: str) -> dict | None:
    """Return a single property by ID (case-insensitive)."""
    props = get_properties()
    pid   = property_id.strip().upper()
    return next((p for p in props if p["id"].upper() == pid), None)

def find_properties(query: str) -> list:
    """
    Simple keyword search across area, beds, title.
    Returns matching active properties (max 3).
    """
    q     = query.lower()
    props = get_properties()
    # Extract a bed count if the user said "3 bedroom" etc.
    bed_number = None
    for word in q.split():
        if word.isdigit():
            bed_number = word
            break

    results = []
    for p in props:
        match = False
        if p["area"].lower() in q:
            match = True
        if bed_number and p["beds"] == bed_number:
            match = True
        if "studio" in q and p["beds"] == "0":
            match = True
        if match:
            results.append(p)

    return results[:3]
