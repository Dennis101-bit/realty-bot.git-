# Harbor Realty WhatsApp Bot — Deployment Guide

## What's in this project

| File | What it does |
|---|---|
| `app.py` | The brain — handles every WhatsApp message and decides what to reply |
| `session.py` | Remembers where each user is in the conversation |
| `sheets.py` | Reads your property listings from Google Sheets |
| `leads.py` | Saves booking requests and emails you when a new lead comes in |
| `requirements.txt` | Python packages to install |
| `.env.example` | Template for your secret keys (rename to `.env`) |
| `Procfile` | Tells Railway/Render how to start the app |

---

## Step 1 — Set up your Google Sheet (listings)

1. Go to [sheets.google.com](https://sheets.google.com) and create a new sheet
2. In row 1, add these exact column headers:
   `ID | Title | Price | Beds | Baths | Sqft | Area | Description | Status`
3. Fill in your properties — set Status to `Active` for any live listing
4. Copy the Spreadsheet ID from the URL (the long string between `/d/` and `/edit`)

---

## Step 2 — Set up your Google Sheet (leads)

1. Create a second Google Sheet for capturing leads
2. In row 1, add: `Name | Phone | Property | Time | Received`
3. Copy this Spreadsheet ID too

---

## Step 3 — Set up Google service account (so your bot can read the sheets)

1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Create a new project → Enable the **Google Sheets API** and **Google Drive API**
3. Go to **IAM & Admin → Service Accounts** → Create a service account
4. Download the JSON key file and rename it `credentials.json` — put it in this folder
5. Copy the service account email (looks like `bot@yourproject.iam.gserviceaccount.com`)
6. **Share both Google Sheets** with that email address (give it Editor access)

---

## Step 4 — Set up Twilio WhatsApp sandbox

1. Sign up at [twilio.com](https://twilio.com) (free)
2. Go to **Messaging → Try it out → Send a WhatsApp message**
3. Follow the sandbox setup — you'll get a sandbox number to test with
4. Note your **Account SID** and **Auth Token** from the Twilio dashboard

---

## Step 5 — Set up SendGrid (email alerts)

1. Sign up at [sendgrid.com](https://sendgrid.com) (free — 100 emails/day)
2. Go to **Settings → API Keys** → Create an API key with Mail Send permission
3. Copy the key — you only see it once

---

## Step 6 — Configure your environment variables

1. Rename `.env.example` to `.env`
2. Fill in all the values:
   - `TWILIO_ACCOUNT_SID` and `TWILIO_AUTH_TOKEN` from Twilio
   - `SPREADSHEET_ID` — your listings sheet ID
   - `LEADS_SPREADSHEET_ID` — your leads sheet ID
   - `SENDGRID_API_KEY` — from SendGrid
   - `AGENT_EMAIL` — where lead notifications go (your email or the agent's)

---

## Step 7 — Deploy to Railway (free tier available)

1. Go to [railway.app](https://railway.app) and sign up with GitHub
2. Click **New Project → Deploy from GitHub repo**
3. Push this folder to a GitHub repo, connect it to Railway
4. In Railway, go to **Variables** and paste in all your `.env` values
5. Railway will deploy automatically — you'll get a public URL like:
   `https://your-app-name.up.railway.app`

---

## Step 8 — Connect Twilio to your live URL

1. In Twilio, go to your **WhatsApp Sandbox settings**
2. In the **"When a message comes in"** field, paste:
   `https://your-app-name.up.railway.app/webhook`
3. Set the method to **HTTP POST**
4. Save

---

## Step 9 — Test it

1. Send "hi" to your Twilio sandbox WhatsApp number from your phone
2. You should see the greeting menu appear
3. Test all three flows: Find Properties, Get Property Info, Book an Appointment
4. Check that booking requests appear in your leads Google Sheet and your email

---

## Going live with a real WhatsApp number (after testing)

1. Apply for a **WhatsApp Business API** account through Twilio
2. Submit your **Meta Business Verification** (takes 2–5 business days)
3. Once approved, Twilio gives you a real WhatsApp number your clients can message
4. Update the webhook URL to point to the same `/webhook` endpoint

---

## Customising for each agent

To white-label this for a specific agent:
- Change `"Harbor Realty"` in `app.py` to their brokerage name
- Update the mock listings in `sheets.py` (or connect their Google Sheet)
- Update `AGENT_EMAIL` in `.env` to their email address
- Redeploy — takes about 2 minutes on Railway

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Bot not responding | Check Railway logs for errors; make sure webhook URL is correct in Twilio |
| "Could not connect to Google Sheets" | Make sure you shared the sheet with the service account email |
| No email notifications | Check SendGrid API key and that FROM_EMAIL is a verified sender |
| Sessions not persisting after restart | Expected with in-memory sessions — switch to Redis for production |
